import assignColorUI
import sequentialRenamerUI
colorUI = assignColorUI.AssignColorUI()
renamerUI = sequentialRenamerUI.SequentialRenamerUI()
# !!! HOW TO USE !!!
# run command `colorUI.create()` in the pYTHON input field in maya
# AFTER script has been placed in the `documents/maya/scripts` folder along with the userSetup.py included in the ZIP.

import maya.cmds as cmds
import random

class AssignColorUI:
    def __init__(self):
        self.window = "assignColorUI"
        self.title = "Assign Color"
        self.size = (400, 300)

    def create(self):
        # check if the window exists
        #delete old window
        if cmds.window(self.window, exists=True):
            cmds.deleteUI(self.window, window=True)
        
        self.window = cmds.window(self.window, title=self.title, widthHeight=self.size)
        cmds.columnLayout(adjustableColumn=True)
        cmds.text(label="Select a color to apply to the selected objects NURBS children:", height = 50)
        cmds.gridLayout(numberOfColumns=8, cellWidthHeight=(50, 50))

        colorArray = [
            (1, (0.0, 0.0, 0.0)),       # black
            (2, (0.25, 0.25, 0.25)),    # dark gray
            (3, (0.5, 0.5, 0.5)),       # light gray
            (4, (0.6, 0.0, 0.0)),       # dark red
            (5, (0.0, 0.0, 0.2)),       # dark blue
            (6, (0.0, 0.0, 1.0)),       # blue
            (7, (0.0, 0.2, 0.0)),       # dark green
            (8, (0.172, 0.075, 0.302)),    # dark purple
            (9, (0.663, 0.188, 0.780)),    # hot pink
            (10, (0.5, 0.25, 0.0)),      # brown
            (11, (0.2, 0.1, 0.0)),      # dark brown
            (12, (0.651, 0.157, 0.071)),  # dark orange
            (13, (1.0, 0.0, 0.0)),      # red
            (14, (0.0, 1.0, 0.0)),         # green
            (15, (0.063, 0.345, 0.522)),   # dark cyan
            (16, (1.0, 1.0, 1.0)),          # white
            (17, (0.902, 0.886, 0.133)),   # yellow
            (18, (0.455, 0.882, 0.949)),   # sky blue
            (19, (0.251, 0.961, 0.722)),   # alien green
            (20, (0.969, 0.765, 0.796)),   # light pink
            (21, (1.0, 0.75, 0.5)),         # light orange
            (22, (0.961, 0.937, 0.498)),    # light yellow
            (23, (0.149, 0.580, 0.322)),    # forest green
            (24, (0.878, 0.647, 0.482)),    # beige
            (25, (0.980, 0.882, 0.490)),    # dark yellow
            (26, (0.702, 0.820, 0.345)),    # lime
            (27, (0.298, 0.831, 0.635)),    # dark cyan
            (28, (0.5, 0.75, 1.0)),         # some ugly blue
            (29, (0.059, 0.627, 0.729)),    # deep blue
            (30, (0.694, 0.545, 0.839)),    # purple
            (31, (0.769, 0.424, 0.769)),    # dark hot pink
        ]
        
        # color buttons 1-31
        for (colorIndex, colorRGB) in colorArray:
            cmds.button(label=" ", command=lambda *args, color=colorIndex: self.setColor(color), backgroundColor=colorRGB)
        
        # random button
        cmds.button(label="Random", command=lambda *args: self.setRandomColor())
        
        # show window
        cmds.showWindow(self.window)

    def setColor(self, colorIndex):
        self.setDrawingOverrideColor(colorIndex)

    def setRandomColor(self):
        colorIndex, colorRGB = random.choice([
            (1, (0.0, 0.0, 0.0)),       # black
            (2, (0.25, 0.25, 0.25)),    # dark gray
            (3, (0.5, 0.5, 0.5)),       # light gray
            (4, (0.6, 0.0, 0.0)),       # dark red
            (5, (0.0, 0.0, 0.2)),       # dark blue
            (6, (0.0, 0.0, 1.0)),       # blue
            (7, (0.0, 0.2, 0.0)),       # dark green
            (8, (0.172, 0.075, 0.302)), # dark purple
            (9, (0.663, 0.188, 0.780)), # hot pink
            (10, (0.5, 0.25, 0.0)),     # brown
            (11, (0.2, 0.1, 0.0)),      # dark brown
            (12, (0.651, 0.157, 0.071)),# dark orange
            (13, (1.0, 0.0, 0.0)),      # red
            (14, (0.0, 1.0, 0.0)),      # green
            (15, (0.063, 0.345, 0.522)),# dark cyan
            (16, (1.0, 1.0, 1.0)),      # white
            (17, (0.902, 0.886, 0.133)),# yellow
            (18, (0.455, 0.882, 0.949)),# sky blue
            (19, (0.251, 0.961, 0.722)),# alien green
            (20, (0.969, 0.765, 0.796)),# light pink
            (21, (1.0, 0.75, 0.5)),     # light orange
            (22, (0.961, 0.937, 0.498)),# light yellow
            (23, (0.149, 0.580, 0.322)),# forest green
            (24, (0.878, 0.647, 0.482)),# beige
            (25, (0.980, 0.882, 0.490)),# dark yellow
            (26, (0.702, 0.820, 0.345)),# lime
            (27, (0.298, 0.831, 0.635)),# dark cyan
            (28, (0.5, 0.75, 1.0)),     # some ugly blue
            (29, (0.059, 0.627, 0.729)),# deep blue
            (30, (0.694, 0.545, 0.839)),# purple
            (31, (0.769, 0.424, 0.769)),# dark hot pink
        ])
        self.setColor(colorIndex)

    def setDrawingOverrideColor(self, colorIndex):
        # get selected
        selectedObjects = cmds.ls(sl=True)
        # empty value check
        if not selectedObjects:
            cmds.warning("Select something, preferably NURBs")
            return

        def applyColorToNurbsShapes(objects):
            shapeNodesColored = 0
            #loop thru each selected obj + children
            for obj in objects:
                # list all children withg nurbs nodes, use fullPath to get true names and guarantee no repeats
                shapeNodes = cmds.listRelatives(obj, allDescendents=True, type='nurbsCurve', fullPath=True) or []
                #loop enable drawing override
                for shape in shapeNodes:
                    cmds.setAttr(shape + ".overrideEnabled", 1)
                    cmds.setAttr(shape + ".overrideColor", colorIndex)
                    #record num of nodes affected
                    shapeNodesColored += 1
            return shapeNodesColored

        # apply color
        shapeNodesColored = applyColorToNurbsShapes(selectedObjects)
        if shapeNodesColored == 0:
            cmds.warning("no NURBs found")
        else:
            print("Color applied to " + str(shapeNodesColored) + " NURBs.")

# create and show
#colorUI = AssignColorUI()
#colorUI.create()